package taller3listestudy;

import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import java.io.File;
import java.io.FileWriter;

/**
 * @author MASTER
 */
public class main {

    File Archivo;
    String rutaJson;

    public main() {
        rutaJson = "Estudiantes.json";
        crearArchiJson();
    }

    public static void main(String[] args) {
        String tempObj, codNot = "0133";
        double suma = 0;
        Gson json = new Gson();
        main main = new main();
        main.crearArchiJson();

        estudiante[] estudi = new estudiante[20];

        profesor pro = new profesor("012", "Sesar Gonsalez", "0133", "sg@cole.co", "3113111714");

        nota[] no = new nota[20];
        materia ma = new materia("0133", "calculo", 3.5, pro);

        no[0] = new nota(codNot, 4.0);
        estudi[0] = new estudiante("Alex", "Fito", "01/02/98", "lol@cole.co", "3137344859", no[0], ma);

        no[1] = new nota(codNot, 4.5);
        estudi[1] = new estudiante("Pepe", "Grillo", "11/11/45", "pG@cole.co", "314514795", no[1], ma);

        no[2] = new nota(codNot, 3.5);
        estudi[2] = new estudiante("Antonio", "Perez", "30/02/80", "Ap@cole.co", "3535353", no[2], ma);

        no[3] = new nota(codNot, 2);
        estudi[3] = new estudiante("Laura", "Cardona", "15/09/00", "Lc@cole.co", "184618", no[3], ma);

        no[4] = new nota(codNot, 3.0);
        estudi[4] = new estudiante("Juliana", "Castaño", "14/03/94", "jC@cole.co", "554421", no[4], ma);

        no[5] = new nota(codNot, 5.0);
        estudi[5] = new estudiante("Jorge", "Perez", "18/08/90", "jp@cole.co", "32266104", no[5], ma);

        no[6] = new nota(codNot, 3.8);
        estudi[6] = new estudiante("Monica", "Aristizabal", "5/01/90", "Ma@cole.co", "8781", no[6], ma);

        no[7] = new nota(codNot, 1.0);
        estudi[7] = new estudiante("Luisa", "Saratoga", "08/04/98", "ls@cole.co", "448941", no[7], ma);

        no[8] = new nota(codNot, 2);
        estudi[8] = new estudiante("Federico", "Crespo", "07/07/97", "Fc@cole.co", "5151", no[8], ma);

        no[9] = new nota(codNot, 4.0);
        estudi[9] = new estudiante("Manuela", "Peralta", "07/08/90", "mp@cole.co", "564561", no[9], ma);


        for (int i = 0; i < 10; i++) {
            suma += estudi[i].getNota().get(0).getNota();
            main.escribirJson(tempObj = json.toJson(estudi[i]));
        }
        System.out.println("EL PROMEDIO DE LOS ESTUDIANTES ES DE:" + suma / 20);
//PUEBA DE DATOS
        // profesor pro1 = new profesor("11", "Milena Salazar", "0234", "ms@cole.co", "322664145");
        //ma.setProfesor(pro1);
        /*System.out.println(ma.getProfesor().size());
        System.out.println(ma.getProfesor().get(0).getCodigoPro());
        System.out.println(ma.getProfesor().get(0).getNombre());
        System.out.println(ma.getProfesor().get(0).getCodigoMa());
        System.out.println(ma.getProfesor().get(0).getCorreo());

        System.out.println(ma.getProfesor().get(1).getCodigoPro());
        System.out.println(ma.getProfesor().get(1).getNombre());
        System.out.println(ma.getProfesor().get(1).getCodigoMa());
        System.out.println(ma.getProfesor().get(1).getCorreo());
         */
    }

    public void crearArchiJson() {
        try {
            Archivo = new File(rutaJson);
            if (Archivo.createNewFile()) {
                System.out.println("Archivo Creado :)");
            }
        } catch (Exception e) {
            System.out.println("Error al Crear archivo\n" + e);
        }
    }

    public void escribirJson(String a) {
        try {
            File Archivo = new File(rutaJson);
            FileWriter escribir = new FileWriter(Archivo, true);
            escribir.write(a + "\r\n");
            escribir.close();

        } catch (Exception e) {
            System.out.println("No se puede Editar el archivo\n" + e);
        }
    }
}
