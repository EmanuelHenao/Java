package taller9genericclass;

public class Main {

    public static void main(String[] args) {
        In<String> bolsa= new In<String>();
        In<Integer> bols= new In<Integer>();
        bols.add(565);
        bolsa.add("queso");
        
    }

}
