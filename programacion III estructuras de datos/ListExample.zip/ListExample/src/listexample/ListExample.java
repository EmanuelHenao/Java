/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listexample;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Pepe
 */
public class ListExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Person person = new Person();
       List<Cars> cars = new ArrayList<>();
       Cars car = new Cars();
       car.setName("BMW");
       cars.add(car);
       
       car.setName("Peugeot");
       cars.add(car);
       
       car.setName("Lamborghini");
       cars.add(car);       

       car.setName("Porge");
       cars.add(car);
       person.setCars(cars);
       
       List<Cars> listCars = person.getCars();
              
       System.out.println("Nombre del auto: " + listCars.get(0).getName());
       System.out.println("Nombre del auto: " + listCars.get(2).getName());
    }
    
}
