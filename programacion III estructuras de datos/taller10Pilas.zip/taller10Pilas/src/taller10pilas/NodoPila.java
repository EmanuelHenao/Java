package taller10pilas;

public class NodoPila {

    int dato;
    NodoPila siguiente;

    public NodoPila(int a) {
        this.dato = a;
        this.siguiente = null;
    }

}
